function submitOrder(button) {

    axios
        .post(`/submitcart`)
        .then((response) => {

            

            thanks = "Your order has been submitted! Thank you for choosing Pappas Pizzeria!";
            document.getElementById('cart-message').textContent = thanks;

            const totalCartQuantity = response.data.cartCount;
            document.getElementById('total-cart-quantity').textContent = totalCartQuantity;

        })
        .catch((error) => {
            console.error('Error updating quantity:', error);
        });
}
