// deletecart.js
function deleteCart() {
    console.log('Deleting cart...');
    axios
        .post(`/deletecart`)
        .then((response) => {
            console.log(response.data);

            const totalCartQuantity = response.data.cartCount;
            document.getElementById('total-cart-quantity').textContent = totalCartQuantity;


            const reOrder = "Your cart has been deleted. Head to the menu to begin adding to cart."
            document.getElementById('cart-message').textContent = reOrder;
        })
        .catch((error) => {
            console.error('Error deleting cart:', error);
        });
}
