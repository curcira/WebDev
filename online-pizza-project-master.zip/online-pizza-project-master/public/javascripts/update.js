// Add this function to your JavaScript file
function updateQuantity(button) {
    const cartId = button.previousElementSibling.dataset.cartId;
    const newQuantity = button.previousElementSibling.value;
    console.log(newQuantity);

    axios
        .post(`/updatecart`, {cartId: cartId, newQuant: newQuantity})
        .then((response) => {

            console.log("response data")
            console.log(response.data)
            
            console.log(response.data);
            // Recalculate and update the total cart quantity
            const totalCartQuantity = response.data.cartCount;
            document.getElementById('total-cart-quantity').textContent = totalCartQuantity;
        })
        .catch((error) => {
            console.error('Error updating quantity:', error);
        });
}
