// delete.js
function deleteItem(button) {
    const cartId = button.previousElementSibling.previousElementSibling.dataset.cartId;

    axios
        .post(`/deleteitem`, { cartId: cartId })
        .then((response) => {
            console.log(response.data);
            
            // Update the total cart quantity
            const totalCartQuantity = response.data.cartCount;
            document.getElementById('total-cart-quantity').textContent = totalCartQuantity;

            // Remove the deleted item from the UI
            const deletedItem = button.parentElement;
            deletedItem.parentNode.removeChild(deletedItem);
        })
        .catch((error) => {
            console.error('Error deleting item:', error);
        });
}
