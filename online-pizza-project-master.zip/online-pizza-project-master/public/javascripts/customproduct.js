document.addEventListener('DOMContentLoaded', function () {
    const addToCartButton = document.querySelector('.custom-to-cart-button');
  
    addToCartButton.addEventListener('click', function () {
        var checkboxes = document.getElementsByName('topping-checkbox');
        const itemName = this.dataset.name;  
        var selectedToppings =[];
        for (var checkbox of checkboxes) {
            if (checkbox.checked) {
              selectedToppings.push(checkbox.value);
              checkbox.checked = false;
            }
        }
  
      axios.post('/customcart', {
        name: itemName, 
        quantity: 1, 
        customizations: selectedToppings
        })
        .then(response => {
          
          const totalCartQuantity = response.data.cartCount;
          document.getElementById('total-cart-quantity').textContent = totalCartQuantity;

          for (var checkbox of checkboxes) {
            checkbox.checked = false;
          }
        })
        .catch(error => {
          console.error('Error adding pizza to cart:', error);
        });
    });
  

  });
  