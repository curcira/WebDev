// public/javascripts/clientcart.js

document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('.add-to-cart-button');
    buttons.forEach(button => {
        button.addEventListener('click', function () {
            var productName = button.dataset.name;
            var productId = button.dataset.id;
           
            axios.post('/cart', {name: productName, prodId: productId, quantity: 1})
                .then(response => {
                    updateCartCount(response.data.cartCount);

                    const totalCartQuantity = response.data.cartCount;
                    document.getElementById('total-cart-quantity').textContent = totalCartQuantity;
                })
                .catch(error => {
                    console.error('Error adding item to cart:', error);
                });
        });
    });

    function updateCartCount(count) {
        
        document.getElementById('cart-count').innerText = count;
    }
});
