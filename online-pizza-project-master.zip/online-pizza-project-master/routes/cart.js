const express = require('express');
const router = express.Router();

router.post('/',  (req, res) => {
    const { name, prodId, quantity } = req.body;

    full_cart = req.session.cart;

    while (true) {
        if (full_cart.length == 0) {
            console.log("cart is 0")
            const newItem = {
                cart_id: req.session.nextCartId,
                product_id: prodId,
                name: name,
                quantity: quantity,
                }
            req.session.cart.push(newItem);
            break;
        } else { 
            for (let i = 0; i < full_cart.length; i++)
            {
             if (full_cart[i].product_id == prodId) {
                 console.log("Found");
                 full_cart[i].quantity += 1;
                 break;
             } else if (i == full_cart.length -1) {
                 const newItem = {
                 cart_id: req.session.nextCartId,
                 product_id: prodId,
                 name: name,
                 quantity: quantity,
                 }
                 req.session.cart.push(newItem);
                 break;
             }
            }
        break;
        }
    }



    req.session.cartCount += quantity;
    req.session.nextCartId++;

    res.status(201).json({
        cartCount: req.session.cartCount,
        cart: req.session.cart,
    });
});



module.exports = router;
