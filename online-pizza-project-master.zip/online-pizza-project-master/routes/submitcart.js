const express = require('express');
const router = express.Router();
const db = require('../db');

router.post('/', async (req, res) => {
    console.log("trying to submit cart")

    full_cart = req.session.cart;
    user = req.session.user.id;

    const orderQuery = 'INSERT into pizza_orders (pizza_customer_id, created_at) VALUES ($1, NOW()) RETURNING id';
    const orderResult = await db.query(orderQuery, [user]); 
    const orderId = orderResult.rows[0].id;

    const orderLinesQuery = 'INSERT into order_lines (pizza_order_id, pizza_product_id, quantity) VALUES ($1, $2, $3) RETURNING id';

    const custOrderQuery = 'INSERT into order_line_customizations (order_line_id, customization_id) VALUES ($1, $2)';

    for (let i = 0; i < full_cart.length; i++){
        if (full_cart[i].product_id == 1) {
            var prodId = full_cart[i].product_id
            var prodQuant = full_cart[i].quantity
            var orderLinesResult = await db.query(orderLinesQuery, [orderId, prodId, prodQuant])
            var orderLineId = orderLinesResult.rows[0].id;
            toppings = full_cart[i].toppingsId;
            for (let i = 0; i < toppings.length; i++) {
                custId = toppings[i];
                await db.query(custOrderQuery, [orderLineId, custId]);
            }


        } else {
            var prodId = full_cart[i].product_id
            var prodQuant = full_cart[i].quantity
            await db.query(orderLinesQuery, [orderId, prodId, prodQuant])
        }
        
    }


    req.session.cart = []
    req.session.cartCount = 0;
    req.session.nextCartId = 1;


    res.status(201).json({
        cartCount: req.session.cartCount,
        cart: req.session.cart,
    });
});



module.exports = router;
