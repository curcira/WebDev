const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../db');

const router = express.Router();

router.get('/register', (req, res) => {
    res.render('register')
});
router.post('/register', async (req, res) => {
    const errors =[];

    if (req.body.password != req.body.passwordConf) {
        errors.push('The provided passwords do not match.');
    }

    if (
        !(
            req.body.name &&
            req.body.email && 
            req.body.username &&
            req.body.password &&
            req.body.passwordConf
        )
    ) {
        errors.push('All fields are required.');
    }

    const selectUserQuery = 
        'SELECT * FROM pizza_customers WHERE username = $1;';
    const selectUserResult = await db.query(selectUserQuery, [req.body.username]);
    console.log(selectUserResult);
    const selectEmailQuery = 
        'SELECT * FROM pizza_customers WHERE email = $1;';
    const selectEmailResult = await db.query(selectEmailQuery, [req.body.email]);
    console.log(selectEmailResult)

    if (selectUserResult.rows.length > 0) {
        errors.push('That username is already taken.');
    }

    if (selectEmailResult.rows.length > 0) {
        errors.push('An account is already registered with that email.');
    }
    if(!errors.length) {
        const insertQuery =
            'INSERT INTO pizza_customers (name, username, email, password) VALUES ($1, $2, $3, $4);';
        const password = await bcrypt.hash(req.body.password, 10);
        await db.query(insertQuery, [req.body.name, req.body.username, req.body.email, password]);

        res.redirect('login');
    } else {
        res.render('register', { errors });
    }
});

router.get('/logout', (req, res) => {
    req.session.destroy(() => res.redirect('/'));
});


router.get('/menu', async (req, res) => {
    const errors = [];
    if (req.session.user) {
        const Drinks = 'Drinks';
        const BYO = 'BYO';
        const Pizzas = 'Pizzas';
        const Sides = 'Sides';
        const Extras = 'Extras';
        const Desserts = 'Desserts';
        const drinkQuery = 'SELECT * FROM pizza_products WHERE category = $1;';
        const selectDrinks = await db.query(drinkQuery, [Drinks]);

        const pizzaQuery = 'SELECT * FROM pizza_products WHERE category = $1;';
        const selectPizzas = await db.query(pizzaQuery, [Pizzas]);

        const byobQuery = 'SELECT * FROM pizza_products WHERE category = $1;';
        const selectByo = await db.query(pizzaQuery, [BYO]);



        const sidesQuery = 'SELECT * FROM pizza_products WHERE category = $1;';
        const selectSides = await db.query(sidesQuery, [Sides]);

        const extrasQuery = 'SELECT * FROM pizza_products WHERE category = $1;';
        const selectExtras = await db.query(extrasQuery, [Extras]);

        const dessertQuery = 'SELECT * FROM pizza_products WHERE category = $1;';
        const selectDesserts = await db.query(dessertQuery, [Desserts]);

        console.log(req.session.user.id)
        res.render('menu', { cartQuant: req.session.cartCount, title: 'Pappas Pizzeria', byo: selectByo.rows, drinks: selectDrinks.rows, pizzas: selectPizzas.rows, sides: selectSides.rows, extras: selectExtras.rows, desserts: selectDesserts.rows, userId: req.session.user.id});
    } else {
        errors.push('You must be logged in to view the Menu. Please log in or create an account.')
        res.render('login', { errors })
    }
});

router.get('/viewcart', async (req, res) => {
    const errors = [];
    if (req.session.user) {
        full_cart = req.session.cart 
        if (full_cart.length == 0) {
            errors.push('Your cart is empty. Add items to cart!');
            const Drinks = 'Drinks';
            res.render('viewcart', { errors })
        } else {
            console.log(req.session.cart);
            res.render('viewcart', {cart: req.session.cart, cartQuant: req.session.cartCount}); 
        }   
    } else {
        errors.push('Please log in to add to and view your cart!');
        res.render('login', {errors});
    }
});

router.get('/:productId/customize', async (req, res) => {
    const { productId } = req.params;

    const descQuery = 'SELECT description FROM pizza_products WHERE id = $1';
    const selectDesc = await db.query(descQuery, [productId]);

    const imgQuery = 'SELECT image FROM pizza_products WHERE id = $1';
    const selectImg = await db.query(imgQuery, [productId]);

    const nameQuery = 'SELECT name FROM pizza_products WHERE id = $1';
    const selectName = await db.query(nameQuery, [productId]);

    const vegQuery = 'SELECT * FROM customizations WHERE category = $1';
    const veg = 'Veggie Topping';
    const selectVeg = await db.query(vegQuery, [veg]);

    const meatQuery = 'SELECT * FROM customizations WHERE category = $1';
    const meat = 'Meat Topping';
    const selectMeat = await db.query(meatQuery, [meat]);


    res.render('customize', {cartQuant: req.session.cartCount, name: selectName.rows, desc: selectDesc.rows, img: selectImg.rows, productId: productId, veggies: selectVeg.rows, meats: selectMeat.rows, user: req.session.user})

});



router.get('/login', (req, res) => {
    res.render('login')
});

router.post('/login', async (req, res) => {
    const errors = [];

    const selectQuery = 
        'SELECT * FROM pizza_customers WHERE username = $1;';
    const selectResult = await db.query(selectQuery, [req.body.username]);

    if (selectResult.rows.length == 1) {
        const auth = await bcrypt.compare(
            req.body.password, 
            selectResult.rows[0].password
        );

        if (auth) {
            [req.session.user] = selectResult.rows;
            console.log(req.session.user);
            const username = req.body.username;
            req.session.cart = [];
            req.session.cartCount = 0;
            req.session.nextCartId = 1;
            req.session.save(() => res.redirect('/'));
        } else {
            errors.push('Incorrect username/password');
            res.render('login', { errors });
        }
    } else {
        errors.push('Incorrect username/password');
        res.render('login', { errors });
    }
});


module.exports = router;