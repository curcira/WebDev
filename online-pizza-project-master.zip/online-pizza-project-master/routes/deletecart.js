// deletecart.js on the server side
const express = require('express');
const router = express.Router();

router.post('/', (req, res) => {
    // Assuming fullCart is a property of req.session
    const fullCart = req.session.cart;

    // Perform logic to delete the entire cart
    req.session.cartCount = 0;
    req.session.cart = [];
    req.session.nextCartId = 1;

    console.log('Cart deleted:', req.session.cart);

    res.json({
        cart: req.session.cart,
        cartCount: req.session.cartCount
    });
});

module.exports = router;
