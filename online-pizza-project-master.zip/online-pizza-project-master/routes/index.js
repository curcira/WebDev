const express = require('express');

const router = express.Router();




/* GET home page. */
router.get('/', (req, res) => {
  if(req.session.user) {
    res.render('userpage', { title: 'Pappas Pizzeria', user: req.session.user })
  } else {
    res.render('index', { title: 'Pappas Pizzeria' });
  }
});

router.get('/register', (req, res) => {
  res.redirect('/users/register');
});

router.get('/login', (req, res) => {
  res.redirect('/users/login');
});

router.get('/menu', (req, res) => {
  res.redirect('/users/menu');
});

router.get('/viewcart', (req, res) => {
  res.redirect('/users/viewcart');
});

router.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});




module.exports = router;
