

const express = require('express');
const router = express.Router();
const db = require('../db');


router.post('/', async (req, res) => {
    const { name, quantity, customizations } = req.body;
    const prodId = 1;
    const user = req.session.user.id;
    console.log(prodId);
    console.log(customizations);

    const toppingQuery = 'SELECT customization from customizations WHERE id = $1';

    const toppings =[]

    for(var arg = 0; arg < customizations.length; ++ arg) {
        const toppingId = customizations[arg];
        const topping = await db.query(toppingQuery, [toppingId]);
        toppings.push(topping.rows[0]['customization']);
    }

    const newItem = {
        cart_id: req.session.nextCartId,
        product_id: prodId,
        name: name,
        toppings: toppings,
        toppingsId: customizations,
        quantity: quantity,
      };



   console.log("TESTTEST")
   console.log(toppings)
    req.session.cart.push(newItem);

   
    req.session.cartCount += quantity;
    req.session.nextCartId++;

    // Return JSON response
    res.status(201).json({
        cartCount: req.session.cartCount,
        cart: req.session.cart,
    });
});

module.exports = router;