const express = require('express');
const router = express.Router();


router.post('/', (req, res) => {
    const cart_id = req.body.cartId;
    const newQuantity = parseInt(req.body.newQuant);
    console.log(cart_id)
    console.log(newQuantity)
    console.log(req.session.cart)

    
   full_cart = req.session.cart;

   for (let i = 0; i < full_cart.length; i++)
   {
    if (full_cart[i].cart_id == cart_id)
    {
        console.log("Found");
        if (newQuantity > full_cart[i].quantity) {
            const updateCartCount = newQuantity - full_cart[i].quantity;
            req.session.cartCount += updateCartCount;
        } else {
            const updateCartCount = full_cart[i].quantity - newQuantity;
            req.session.cartCount = req.session.cartCount - updateCartCount;
        }
        full_cart[i].quantity = newQuantity;
        break;
    }
   }

   console.log(req.session.cartCount)
   

    res.json({
        cart: req.session.cart,
        cartCount: req.session.cartCount
    });
});

module.exports = router;