const express = require('express');
const router = express.Router();

router.post('/', (req, res) => {
    const cartId = req.body.cartId;
    fullCart = req.session.cart;

    for (let i = 0; i < fullCart.length; i++) {
        console.log(cartId);
        if (fullCart[i].cart_id == cartId) {
            console.log("Found");
            req.session.cartCount -= fullCart[i].quantity;
            fullCart.splice(i, fullCart[i].quantity);
        }
    }
    console.log(fullCart);

    res.json({
        cart: req.session.cart,
        cartCount: req.session.cartCount
    });
});

module.exports = router;
